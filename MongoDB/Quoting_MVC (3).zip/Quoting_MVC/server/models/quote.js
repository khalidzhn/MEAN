const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/qouts_DB', { useNewUrlParser: true });


module.exports = function () {

    const QuoteSchema = new mongoose.Schema({
        name: { type: String, required: true, minlength: 2 },
        message: { type: String, required: true, minlength: 2 }
    }, { timestamps: true })
    // create an object to that contains methods for mongoose to interface with MongoDB
    const Quote = mongoose.model('Quote', QuoteSchema);
}